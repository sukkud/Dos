﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoLoginApplication
{
    public partial class ProjectReviewInformation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.User.Identity.IsAuthenticated)
            {
                FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                state.DataSource = StateNameList().Tables[0];
                state.DataTextField = "StateName";
                state.DataBind();
                state.Items.Insert(0, new ListItem("--Select--", "NA"));
            }
        }

        protected DataSet StateNameList()
        {
            DataSet dsStates = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("Web_SR_GetStates", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dsStates);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsStates;
        }

        //protected void Chkbox_CheckedChanged(object sender, EventArgs e)

        //{
        //    if (Chkbox.Checked)
        //        Test.Enabled = true;
        //    else
        //        Test.Enabled = false;
        //}

        protected void Tab1_Click(object sender, EventArgs e)
        {
            Tab1.CssClass = "Clicked";
            Tab2.CssClass = "Initial";
            MainView.ActiveViewIndex = 0;
        }
        protected void Tab2_Click(object sender, EventArgs e)
        {
            Tab1.CssClass = "Initial";
            Tab2.CssClass = "Clicked";
            MainView.ActiveViewIndex = 1;
        }
    }
}