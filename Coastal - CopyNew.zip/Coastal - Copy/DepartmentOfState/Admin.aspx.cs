﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace DemoLoginApplication
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.User.Identity.IsAuthenticated)
            {
                FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
                SqlConnection con = new SqlConnection(constr);
                con.Open();

                SqlCommand com = new SqlCommand("select *from REVIEW.LK_USER_ROLE_TYPE", con);
                SqlDataAdapter da = new SqlDataAdapter(com);
                DataSet ds = new DataSet();
                da.Fill(ds);
                roleType.DataTextField = ds.Tables[0].Columns["Short_Desc"].ToString();
                NewRole.DataTextField = ds.Tables[0].Columns["Short_Desc"].ToString();
                roleType.DataSource = ds.Tables[0];
                NewRole.DataSource = ds.Tables[0];
                roleType.DataBind();
                NewRole.DataBind();
                roleType.Items.Insert(0, new ListItem("--Select--", "NA"));
                NewRole.Items.Insert(0, new ListItem("--Select--", "NA"));
            }
        }
        protected void btnAddUserInfo(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("AddUser", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                     
                        cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = firstname.Value;
                        cmd.Parameters.Add("@Lastname", SqlDbType.VarChar).Value = lastname.Value;
                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value =login.Value;
                        cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password.Value;
                        cmd.Parameters.Add("@RoleType", SqlDbType.VarChar).Value = roleType.SelectedItem.ToString();
                        cmd.Parameters.Add("@CreatedDate", SqlDbType.VarChar).Value = DateTime.Now;
                        cmd.Parameters.Add("@DeactivatedDate", SqlDbType.VarChar).Value = DateTime.Now.AddDays(365);
                        
                        con.Open();
                        cmd.ExecuteNonQuery();
                        bool success = Convert.ToBoolean(cmd.ExecuteScalar());
                        if (success)
                        {
                            //Console.WriteLine("SQL Error" + ex.Message.ToString());
                            string message = "Your details have been saved successfully.";
                            string script = "window.onload = function(){ alert('";
                            script += message;
                            script += "')};";
                            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);

                            //Response.Write("User created");
                        }
                        else
                        {
                            string message = "User Esists.";
                            string script = "window.onload = function(){ alert('";
                            script += message;
                            script += "')};";
                            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);

                            //Response.Write("User exists");
                        }
                       
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        protected void DeleteUser(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("DeleteUser", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                                             
                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = UserName.Value;
                     
                        con.Open();
                        cmd.ExecuteNonQuery();
                        string message = "Successfully Deleted.";
                        string script = "window.onload = function(){ alert('";
                        script += message;
                        script += "')};";
                        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        protected void InactiveUser(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("InactivateUser", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = InactiveUserName.Value;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        string message = "User Inactivated.";
                        string script = "window.onload = function(){ alert('";
                        script += message;
                        script += "')};";
                        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        protected void ActivateUser(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("ActivateUser", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = ActivateUserName.Value;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        string message = "User activated successfully.";
                        string script = "window.onload = function(){ alert('";
                        script += message;
                        script += "')};";
                        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        protected void ModifyUserRole(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("ModifyUserRole", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = ModifyUserName.Value;
                        cmd.Parameters.Add("@NewRoleType", SqlDbType.NVarChar).Value = NewRole.SelectedItem.Value;

                       // cmd.Parameters.Add("@ExistingRole", SqlDbType.NVarChar).Value = ParameterDirection.Output;
                                              
                        con.Open();
                        cmd.ExecuteNonQuery();
                        string message = "Successfully updated.";
                        string script = "window.onload = function(){ alert('";
                        script += message;
                        script += "')};";
                        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                        //string abcd = cmd.Parameters.Add("@ExistingRole", SqlDbType.NVarChar).Value;
                        con.Close();

                    }

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        protected void ResetPassword(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("ResetPassword", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = UsrName.Value;
                        cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = ResetUserPassword.Value;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        string message = "Successfully Updated.";
                        string script = "window.onload = function(){ alert('";
                        script += message;
                        script += "')};";
                        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
    }
}