﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Permissions;
using System.DirectoryServices;
using System.DirectoryServices.ActiveDirectory;


namespace DemoLoginApplication
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.Cookies["UserName"] != null && Request.Cookies["Password"] != null)
                {
                    txtUsername.Text = Request.Cookies["UserName"].Value;
                    txtPassword.Attributes["value"] = Request.Cookies["Password"].Value;
                }
            }
        }

        public DirectorySearcher dirSearch = null;

        protected void Validateuser(object sender, EventArgs e)
        {
            SearchResult result = null;
            string lblUsernameDisplay, lblFirstname, lblMiddleName, lblLastName, lblEmailId;
            string lblTitle, lblCompany, lblCity, lblState, lblCountry, lblPostal, lblTelephone;

            if (txtUsername.Text.Trim().Length != 0 && txtPassword.Text.Trim().Length != 0 )
            {
              result =  GetUserInformation(txtUsername.Text.Trim(), txtPassword.Text.Trim(), "dos.state.ny.us");
            }
            else
            {
                lblError.Text = "Username and/ or Password is invalid";
            }


            //Properties of the Login User
            if (result.GetDirectoryEntry().Properties["samaccountname"].Value != null)
                lblUsernameDisplay = "Username : " + result.GetDirectoryEntry().Properties["samaccountname"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["givenName"].Value != null)
                lblFirstname = "First Name : " + result.GetDirectoryEntry().Properties["givenName"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["initials"].Value != null)
                lblMiddleName = "Middle Name : " + result.GetDirectoryEntry().Properties["initials"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["sn"].Value != null)
                lblLastName = "Last Name : " + result.GetDirectoryEntry().Properties["sn"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["mail"].Value != null)
                lblEmailId = "Email ID : " + result.GetDirectoryEntry().Properties["mail"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["title"].Value != null)
                lblTitle = "Title : " + result.GetDirectoryEntry().Properties["title"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["company"].Value != null)
                lblCompany = "Company : " + result.GetDirectoryEntry().Properties["company"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["l"].Value != null)
                lblCity = "City : " + result.GetDirectoryEntry().Properties["l"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["st"].Value != null)
                lblState = "State : " + result.GetDirectoryEntry().Properties["st"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["co"].Value != null)
                lblCountry = "Country : " + result.GetDirectoryEntry().Properties["co"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["postalCode"].Value != null)
                lblPostal = "Postal Code : " + result.GetDirectoryEntry().Properties["postalCode"].Value.ToString();

            if (result.GetDirectoryEntry().Properties["telephoneNumber"].Value != null)
                lblTelephone = "Telephone No. : " + result.GetDirectoryEntry().Properties["telephoneNumber"].Value.ToString();

            //Get the role type from database 

            //Compare User details. If both matches, allow to access the application


            //Don't delete below code
            //int userId = 0;
            //string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //using (SqlConnection con = new SqlConnection(connStr))
            //{
            //    using (SqlCommand cmd = new SqlCommand("validate_user", con))
            //    {
            //        cmd.CommandType = System.Data.CommandType.StoredProcedure;
            //        cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
            //        cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
            //        con.Open();
            //        userId = Convert.ToInt32(cmd.ExecuteScalar());
            //        //userId = 1;
            //    }
            //    switch (userId)
            //    {
            //        case -1:
            //            lblError.Text = "Username and/ or Password is invalid";
            //            break;
            //        case -2:
            //            lblError.Text = "Account has not been activated";
            //            break;
            //        default:
            //            FormsAuthentication.RedirectFromLoginPage(txtUsername.Text, true);
            //            break;
            //    }
            //}
            //Don't delete above code


            //if (RememberMe.Checked)
            //{
            //    Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(30);
            //    Response.Cookies["Password"].Expires = DateTime.Now.AddDays(30);
            //}
            //else
            //{
            //    Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-1);
            //    Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);

            //}
            //Response.Cookies["UserName"].Value = txtUsername.Text.Trim();
            //Response.Cookies["Password"].Value = txtPassword.Text.Trim();
        }


        private SearchResult GetUserInformation(string username, string passowrd, string domain)
        {
             SearchResult rs = null;
            domain = "dos.state.ny.us";
            if (txtUsername.Text.Trim().IndexOf("@") > 0)
                rs = SearchUserByEmail(GetDirectorySearcher(username, passowrd, domain), txtUsername.Text.Trim());
            else
                rs = SearchUserByUserName(GetDirectorySearcher(username, passowrd, domain), txtUsername.Text.Trim());

            if (rs == null)
            {
                lblError.Text = "User not found!!!";
            }
            return rs;          
        }


        private DirectorySearcher GetDirectorySearcher(string username, string passowrd, string domain)
        {
            if (dirSearch == null)
            {
                try
                {
                    dirSearch = new DirectorySearcher(
                        new DirectoryEntry("LDAP://" + domain, username, passowrd));
                }
                catch (DirectoryServicesCOMException e)
                {
                    lblError.Text = "Connection Creditial is Wrong!!!, please Check.";
                    e.Message.ToString();
                }
                return dirSearch;
            }
            else
            {
                return dirSearch;
            }
        }
        
        private SearchResult SearchUserByUserName(DirectorySearcher ds, string username)
        {
            ds.Filter = "(&((&(objectCategory=Person)(objectClass=User)))(samaccountname=" + username + "))";

            ds.SearchScope = SearchScope.Subtree;
            ds.ServerTimeLimit = TimeSpan.FromSeconds(90);

            SearchResult userObject = ds.FindOne();

            if (userObject != null)
                return userObject;
            else
                return null;
        }

        private SearchResult SearchUserByEmail(DirectorySearcher ds, string email)
        {
            ds.Filter = "(&((&(objectCategory=Person)(objectClass=User)))(mail=" + email + "))";

            ds.SearchScope = SearchScope.Subtree;
            ds.ServerTimeLimit = TimeSpan.FromSeconds(90);

            SearchResult userObject = ds.FindOne();

            if (userObject != null)
                return userObject;
            else
                return null;
        }

    }
}
