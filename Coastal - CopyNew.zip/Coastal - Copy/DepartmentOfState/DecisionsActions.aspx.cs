﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoLoginApplication
{
    public partial class DecisionsActions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.User.Identity.IsAuthenticated)
            {
                FormsAuthentication.RedirectToLoginPage();
            }
        }
        protected void Chkbox_CheckedChanged(object sender, EventArgs e)

        {
            if (Chkbox.Checked)
                Test.Enabled = true;
            else
                Test.Enabled = false;
        }
                
    }
}