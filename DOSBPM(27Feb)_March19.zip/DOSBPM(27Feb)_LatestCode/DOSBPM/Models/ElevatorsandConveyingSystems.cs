﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DOSBPM.Models
{
    public class ElevatorsandConveyingSystems
    {
        public string txtExpSeparatePlan { get; set; }
        public string txtExpEmergencyOp { get; set; }
        public string txtExpAccStretcher { get; set; }
        public string txtExpMachineRoom { get; set; }
        public string txtExpFireServElev { get; set; }
        public string txtExpAdditionalInfo { get; set; }
        //StoragePlan
        public string txtCCD { get; set; }
        public string txtCIS { get; set; }
        public string txtPgNo { get; set; }
        public string txtApplicantComments { get; set; }
        public string txtBackOffComments { get; set; }

    }
}